const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');
const app = express();

app.use(express.json());

// Endpoint to handle code compilation and execution
app.post('/api/compile', (req, res) => {
    const { code, language } = req.body;

    if (language === 'java') {
        // Write Java code to a file
        fs.writeFileSync('Solution.java', code);

        // Compile and execute Java code
        exec('javac Solution.java && java Solution', (err, stdout, stderr) => {
            if (err || stderr) {
                return res.json({ success: false, error: stderr || err.message });
            }
            res.json({ success: true, output: stdout });
        });
    } else if (language === 'python') {
        // Write Python code to a file
        fs.writeFileSync('solution.py', code);

        // Execute Python code
        exec('python3 solution.py', (err, stdout, stderr) => {
            if (err || stderr) {
                return res.json({ success: false, error: stderr || err.message });
            }
            res.json({ success: true, output: stdout });
        });
    } else {
        res.json({ success: false, error: 'Unsupported language' });
    }
});

// Start the server on port 8000
app.listen(8000, () => {
    console.log('Server running on port 8000');
});
