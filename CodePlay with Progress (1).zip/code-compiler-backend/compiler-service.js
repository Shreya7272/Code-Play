const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

class CompilerService {
    constructor() {
        this.tempDir = path.join(__dirname, 'temp');
        this.initTempDir();
    }

    async initTempDir() {
        try {
            await fs.mkdir(this.tempDir, { recursive: true });
            console.log('Temp directory initialized:', this.tempDir);
        } catch (error) {
            console.error('Error creating temp directory:', error);
            throw new Error('Failed to initialize compiler service');
        }
    }

    async cleanup(filePath, className) {
        try {
            // Only attempt to delete files if they exist
            const javaFile = filePath;
            const classFile = path.join(this.tempDir, `${className}.class`);

            const files = [javaFile, classFile];
            for (const file of files) {
                try {
                    await fs.access(file);
                    await fs.unlink(file);
                    console.log('Cleaned up file:', file);
                } catch (err) {
                    if (err.code !== 'ENOENT') {
                        console.warn('Warning during cleanup:', err);
                    }
                }
            }
        } catch (error) {
            console.warn('Warning during cleanup:', error);
        }
    }

    async compile(code, className = 'Solution') {
        const fileName = `${className}.java`;
        const filePath = path.join(this.tempDir, fileName);

        try {
            // Ensure temp directory exists
            await this.initTempDir();

            // Add class declaration if missing
            if (!code.includes('class')) {
                code = `public class ${className} {\n    public static void main(String[] args) {\n        ${code}\n    }\n}`;
            }

            // Write the code to a temporary file
            await fs.writeFile(filePath, code);
            console.log('Code written to:', filePath);

            // Compile the code
            const compileResult = await this.executeCommand(`javac "${filePath}"`);
            if (compileResult.error) {
                const error = this.parseCompileError(compileResult.error);
                const hints = this.generateHints(compileResult.error);
                await this.cleanup(filePath, className);
                return { success: false, error, hints };
            }

            console.log('Compilation successful');

            // Run the compiled code
            const runResult = await this.executeCommand(`cd "${this.tempDir}" && java ${className}`);
            await this.cleanup(filePath, className);

            if (runResult.error) {
                return {
                    success: false,
                    error: runResult.error,
                    hints: this.generateRuntimeHints(runResult.error)
                };
            }

            return {
                success: true,
                output: runResult.output
            };

        } catch (error) {
            console.error('Compilation error:', error);
            await this.cleanup(filePath, className);
            return {
                success: false,
                error: error.message,
                hints: ['Check your code syntax', 'Make sure the class name matches the filename']
            };
        }
    }

    executeCommand(command) {
        return new Promise((resolve) => {
            exec(command, (error, stdout, stderr) => {
                resolve({
                    error: error ? stderr : null,
                    output: stdout
                });
            });
        });
    }

    parseCompileError(error) {
        // Extract meaningful error message
        const errorLines = error.split('\n');
        const relevantError = errorLines.find(line => line.includes('error:'));
        return relevantError || error;
    }

    generateHints(error) {
        const hints = [];
        const errorLower = error.toLowerCase();

        // Common compilation errors and their hints
        if (errorLower.includes('cannot find symbol')) {
            hints.push('Check if you have declared all variables and methods');
            hints.push('Verify the spelling of variable and method names');
        } else if (errorLower.includes('missing')) {
            hints.push('Check for missing semicolons or parentheses');
            hints.push('Ensure all code blocks are properly closed');
        } else if (errorLower.includes('incompatible types')) {
            hints.push('Check if the variable types match your assignments');
            hints.push('You might need to cast the value to the correct type');
        }

        // Add general hints
        hints.push('Review your code syntax');
        hints.push('Make sure your code follows Java conventions');

        return hints;
    }

    generateRuntimeHints(error) {
        const hints = [];
        const errorLower = error.toLowerCase();

        // Common runtime errors and their hints
        if (errorLower.includes('nullpointerexception')) {
            hints.push('Check if you are using an object before initializing it');
            hints.push('Make sure all objects are properly instantiated');
        } else if (errorLower.includes('arrayindexoutofbounds')) {
            hints.push('Verify your array indices are within bounds');
            hints.push('Check your loop conditions when accessing arrays');
        }

        return hints;
    }
}

module.exports = new CompilerService();
