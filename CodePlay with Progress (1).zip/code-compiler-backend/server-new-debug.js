const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 8000;

// Debug middleware to log all requests
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// Basic middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Mount API routes with explicit path
app.use('/api', (req, res, next) => {
    console.log(`[API Route] ${req.method} ${req.url}`);
    next();
}, routes);

// Serve static files with logging
const staticPath = path.join(__dirname, '..', 'CodePlay');
app.use(express.static(staticPath));
console.log(`Static files being served from: ${staticPath}`);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
    console.log(`[404] ${req.method} ${req.url}`);
    res.status(404).json({ error: 'Not found' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    console.log('\nAvailable routes:');
    console.log('- GET /api/test');
    console.log('- GET /api/health');
    console.log('- POST /api/compile');
    console.log('- GET /api/solution/:problemId');
    console.log('\nStatic files:');
    console.log('- /practice-java.html');
    console.log('- /index.html');
});
