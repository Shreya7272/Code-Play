const express = require('express');
const router = express.Router();
const compilerService = require('./compiler-service');

// Test endpoint
router.get('/test', (req, res) => {
    console.log('Test endpoint hit');
    res.json({ message: 'API test endpoint is working' });
});

// Health check endpoint
router.get('/health', (req, res) => {
    console.log('Health check endpoint hit');
    res.json({ status: 'healthy' });
});

// Debug endpoint to list all registered routes
router.get('/routes', (req, res) => {
    console.log('Routes endpoint hit');
    const routes = [];
    router.stack.forEach((middleware) => {
        if (middleware.route) {
            routes.push({
                path: middleware.route.path,
                methods: Object.keys(middleware.route.methods)
            });
        }
    });
    res.json({ routes });
});

// Real-time compilation endpoint
router.post('/compile', async (req, res) => {
    console.log('Real-time compile endpoint hit');
    const { code } = req.body;
    
    if (!code) {
        return res.status(400).json({
            success: false,
            error: 'No code provided',
            hints: ['Please write some code first']
        });
    }

    try {
        const result = await compilerService.compile(code);
        res.json(result);
    } catch (error) {
        console.error('Compilation error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error occurred',
            hints: ['There was a problem processing your code']
        });
    }
});

// Update score endpoint
router.post('/update-score', (req, res) => {
    console.log('Update score endpoint hit:', req.body);
    // In a real app, this would save to a database
    res.json({ success: true, message: 'Score updated' });
});

// Get multiple solutions for a problem
router.get('/solutions/:problemId', (req, res) => {
    console.log('Solutions endpoint hit for problem:', req.params.problemId);
    
    // Map frontend problem IDs to solution IDs
    const problemMap = {
        'basic_1': 'variables_1',
        'basic_2': 'operators_1',
        'basic_3': 'control_1',
        'oop_1': 'classes_1',
        'oop_2': 'objects_1',
        'oop_3': 'inheritance_1',
        'dsa_1': 'arrays_1',
        'dsa_2': 'loops_1',
        'dsa_3': 'algorithms_1'
    };

    // Solutions database with multiple approaches
    const solutions = {
        'variables_1': {
            basic: {
                code: `public class Solution {
    public static void main(String[] args) {
        int score = 100;
        System.out.println("Score: " + score);
    }
}`,
                description: 'Simple approach using direct variable declaration and initialization'
            },
            withValidation: {
                code: `public class Solution {
    public static void main(String[] args) {
        int score;
        score = 100;
        if (score >= 0) {
            System.out.println("Score: " + score);
        } else {
            System.out.println("Invalid score");
        }
    }
}`,
                description: 'Advanced approach with validation check'
            },
            withConstant: {
                code: `public class Solution {
    private static final int DEFAULT_SCORE = 100;
    
    public static void main(String[] args) {
        int score = DEFAULT_SCORE;
        System.out.println("Score: " + score);
    }
}`,
                description: 'Using constant for better maintainability'
            }
        },
        'arrays_1': {
            basic: {
                code: `public class Solution {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        for (int num : numbers) {
            System.out.print(num + " ");
        }
    }
}`,
                description: 'Simple array initialization with for-each loop'
            },
            withArrayList: {
                code: `import java.util.ArrayList;
import java.util.Arrays;

public class Solution {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        numbers.forEach(num -> System.out.print(num + " "));
    }
}`,
                description: 'Using ArrayList for dynamic array operations'
            },
            withStream: {
                code: `import java.util.Arrays;

public class Solution {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        Arrays.stream(numbers)
              .forEach(num -> System.out.print(num + " "));
    }
}`,
                description: 'Modern approach using Java Streams'
            }
        }
    };

    const solutionId = problemMap[req.params.problemId];
    const problemSolutions = solutions[solutionId];
    
    if (!problemSolutions) {
        return res.status(404).json({
            success: false,
            error: 'Solutions not found'
        });
    }

    res.json({
        success: true,
        solutions: problemSolutions
    });
});

module.exports = router;
