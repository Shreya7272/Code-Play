const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Test route to verify server is working
app.get('/api/test', (req, res) => {
    res.json({ message: 'Server is working' });
});

// API Routes
app.use('/api', routes);

// Serve static files from CodePlay directory
const staticPath = path.join(__dirname, '..', 'CodePlay');
console.log('Serving static files from:', staticPath);
app.use(express.static(staticPath));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
