const express = require('express');
const cors = require('cors');
const routes = require('./routes-final');
const path = require('path');

const app = express();
const port = 8000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..'))); // Serve files from parent directory

// Routes
app.use('/api', routes);
const aiRoutes = require('./routes-ai');
app.use('/api', aiRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        error: 'Internal Server Error',
        hints: ['An unexpected error occurred', 'Please try again']
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
