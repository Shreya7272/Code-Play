const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = 8000;

app.use(cors());
app.use(bodyParser.json());

// Directory to store temporary code files
const TEMP_DIR = path.join(__dirname, 'temp');
fs.mkdir(TEMP_DIR, { recursive: true }).catch(console.error);

async function executeJava(code) {
    // const timestamp = Date.now(); // No longer needed for the filename
    const className = `Solution`; // Force the class name for the output directory
    const javaFilename = path.join(TEMP_DIR, `${className}.java`); // Always Solution.java
    const outputDir = path.join(TEMP_DIR, 'output');
    await fs.mkdir(outputDir, { recursive: true });
    const outputFilename = path.join(outputDir, className);

    try {
        await fs.writeFile(javaFilename, code);
        const compileCommand = `javac -d ${outputDir} ${javaFilename}`;
        const compileResult = await new Promise((resolve, reject) => {
            exec(compileCommand, (error, stdout, stderr) => {
                if (error) {
                    reject({ error: stderr });
                } else {
                    resolve({ stdout });
                }
            });
        });

        if (compileResult.error) {
            return { success: false, error: compileResult.error };
        }

        const executeCommand = `java -classpath ${outputDir} ${className}`;
        const executeResult = await new Promise((resolve, reject) => {
            exec(executeCommand, (error, stdout, stderr) => {
                if (error) {
                    reject({ error: stderr });
                } else {
                    resolve({ stdout });
                }
            });
        });

        return { success: true, output: executeResult.stdout.trim() };

    } catch (error) {
        return { success: false, error: error.error || error.message };
    } finally {
        // Clean up temporary files
        await fs.unlink(javaFilename).catch(() => {});
        await fs.rm(outputDir, { recursive: true, force: true }).catch(() => {});
    }
}

app.post('/api/compile', async (req, res) => {
    const { code } = req.body;
    if (!code) {
        return res.status(400).json({ success: false, error: 'No code provided.' });
    }

    const result = await executeJava(code);
    res.json(result);
});

const solutions = {
    'basic_1': {
        'standard': {
            description: 'A straightforward way to declare an integer variable and print its value.',
            code: `public class Solution {
    public static void main(String[] args) {
        int score = 100;
        System.out.println("Score: " + score);
    }
}`
        },
        'alternative': {
            description: 'Using a different variable name but achieving the same result.',
            code: `public class Solution {
    public static void main(String[] args) {
        int playerPoints = 100;
        System.out.println("Score: " + playerPoints);
    }
}`
        }
    },
    'basic_2': {
        'arithmetic': {
            description: 'Calculating the average using basic arithmetic operators.',
            code: `public class Solution {
    public static void main(String[] args) {
        int score1 = 95;
        int score2 = 85;
        int score3 = 75;
        double average = (score1 + score2 + score3) / 3.0;
        System.out.println("Average Score: " + average);
    }
}`
        }
    },
    'basic_3': {
        'modulo': {
            description: 'Using the modulo operator to check for even or odd.',
            code: `public class Solution {
    public static void main(String[] args) {
        int number = 15;
        if (number % 2 == 0) {
            System.out.println(number + " is even");
        } else {
            System.out.println(number + " is odd");
        }
    }
}`
        }
    },
    'basic_4': {
        'iterative': {
            description: 'Calculating factorial using a for loop.',
            code: `public class Solution {
    public static void main(String[] args) {
        int num = 5;
        long factorial = 1;
        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
        System.out.println("Factorial of " + num + " is " + factorial);
    }
}`
        },
        'recursive': {
            description: 'Calculating factorial using a recursive function.',
            code: `public class Solution {
    public static long factorial(int n) {
        if (n == 0)
            return 1;
        else
            return(n * factorial(n-1));
    }
    public static void main(String[] args) {
        int num = 5;
        long result = factorial(num);
        System.out.println("Factorial of " + num + " is " + result);
    }
}`
        }
    },
    'basic_5': {
        'loop': {
            description: 'Iterating through the array to calculate the sum.',
            code: `public class Solution {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of array elements: " + sum);
    }
}`
        }
    },
    'oop_1': {
        'basic_class': {
            description: 'Defining a simple Student class with attributes and a constructor.',
            code: `public class Student {
    String name;
    char grade;

    public Student(String name, char grade) {
        this.name = name;
        this.grade = grade;
    }

    public void display() {
        System.out.println("Student: " + name + ", Grade: " + grade);
    }

    public static void main(String[] args) {
        Student student = new Student("John", 'A');
        student.display();
    }
}`
        }
    },
    'oop_2': {
        'inheritance_example': {
            description: 'Demonstrating inheritance with a Shape base class and a Circle derived class.',
            code: `class Shape {
    String name;
    public Shape(String name) {
        this.name = name;
    }
    public void display() {
        System.out.println("Shape: " + name);
    }
}

class Circle extends Shape {
    double radius;
    public Circle(double radius) {
        super("Circle");
        this.radius = radius;
    }
    public void display() {
        System.out.println("Circle with radius " + radius);
    }
    public static void main(String[] args) {
        Circle circle = new Circle(5.0);
        circle.display();
    }
}`
        }
    },
    'oop_3': {
        'method_overriding': {
            description: 'Illustrating polymorphism through method overriding of an area calculation.',
            code: `class Shape {
    public double area() {
        return 0;
    }
}

class Circle extends Shape {
    double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
    public static void main(String[] args) {
        Shape shape = new Circle(5.0);
        System.out.println("Area of circle: " + String.format("%.2f", shape.area()));
    }
}`
        }
    },
    'oop_4': {
        'interface_example': {
            description: 'Creating a Drawable interface and implementing it in a Circle class.',
            code: `interface Drawable {
    void draw(int x, int y);
}

class Circle implements Drawable {
    double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    @Override
    public void draw(int x, int y) {
        System.out.println("Drawing a circle at (" + x + ", " + y + ")");
    }
    public static void main(String[] args) {
        Circle circle = new Circle(5.0);
        circle.draw(10, 20);
    }
}`
        }
    },
    'oop_5': {
        'abstract_class_example': {
            description: 'Using an abstract Shape class and a concrete Circle class that extends it.',
            code: `abstract class Shape {
    abstract double area();
}

class Circle extends Shape {
    double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
    public static void main(String[] args) {
        Shape circle = new Circle(5.0);
        System.out.println("Circle area: " + String.format("%.2f", circle.area()));
    }
}`
        }
    },
    'dsa_1': {
        'array_operations': {
            description: 'Implementing basic array search (linear) and sort (using Arrays.sort).',
            code: `import java.util.Arrays;

public class Solution {
    public static boolean search(int[] arr, int target) {
        for (int num : arr) {
            if (num == target) {
                return true;
            }
        }
        return false;
    }

    public static int[] sort(int[] arr) {
        Arrays.sort(arr);
        return arr;
    }

    public static void main(String[] args) {
        int[] numbers = {5, 2, 4, 1, 3};
        int target = 4;
        System.out.println("Found " + target + ": " + search(numbers, target));
        int[] sortedNumbers = sort(numbers);
        System.out.println("Sorted array: " + Arrays.toString(sortedNumbers));
    }
}`
        }
    },
    'dsa_2': {
        'linked_list_operations': {
            description: 'A simple singly linked list implementation with add and remove operations.',
            code: `class Node {
    int data;
    Node next;
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public void remove(int data) {
        if (head == null) return;
        if (head.data == data) {
            head = head.next;
            return;
        }
        Node current = head;
        while (current.next != null && current.next.data != data) {
            current = current.next;
        }
        if (current.next != null) {
            current.next = current.next.next;
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + (current.next != null ? " -> " : ""));
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.display();
    }
}`
        }
    },
    'dsa_3': {
        'stack_implementation': {
            description: 'Implementing a stack using an ArrayList.',
            code: `import java.util.ArrayList;
import java.util.List;

class Stack {
    private List<Integer> stackList = new ArrayList<>();

    public void push(int item) {
        stackList.add(item);
    }

    public int pop() {
        if (isEmpty()) {
            return -1; // Or throw an exception
        }
        return stackList.remove(stackList.size() - 1);
    }

    public boolean isEmpty() {
        return stackList.isEmpty();
    }

    public void display() {
        System.out.println("Stack: " + stackList);
    }

    public static void main(String[] args) {
        Stack stack = new Stack();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.display();
    }
}`
        }
    },
    'dsa_4': {
        'queue_implementation': {
            description: 'Implementing a queue using an ArrayList.',
            code: `import java.util.ArrayList;
import java.util.List;

class Queue {
    private List<Integer> queueList = new ArrayList<>();

    public void enqueue(int item) {
        queueList.add(item);
    }

    public int dequeue() {
        if (isEmpty()) {
            return -1; // Or throw an exception
        }
        return queueList.remove(0);
    }

    public boolean isEmpty() {
        return queueList.isEmpty();
    }

    public void display() {
        System.out.println("Queue: " + queueList);
    }

    public static void main(String[] args) {
        Queue queue = new Queue();
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.display();
    }
}`
        }
    },
    'dsa_5': {
        'binary_search_implementation': {
            description: 'Implementing the binary search algorithm on a sorted array.',
            code: `import java.util.Arrays;

public class Solution {
    public static int binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return -1; // Not found
    }

    public static void main(String[] args) {
        int[] numbers = {2, 5, 7, 8, 11, 12};
        int target = 7;
        int index = binarySearch(numbers, target);
        if (index != -1) {
            System.out.println("Found " + target + " at index " + index);
        } else {
            System.out.println(target + " not found in the array.");
        }
    }
}`
        }
    }
};

app.get('/api/solutions/:problemId', (req, res) => {
    const { problemId } = req.params;
    if (solutions[problemId]) {
        res.json({ success: true, solutions: solutions[problemId] });
    } else {
        res.status(404).json({ success: false, error: 'Solution not found for this problem.' });
    }
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});